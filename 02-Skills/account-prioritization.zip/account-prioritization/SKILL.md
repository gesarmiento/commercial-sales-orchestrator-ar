---
name: account-prioritization
description: prioriza, compara y clasifica cuentas enterprise de hiberus argentina con un scoring comercial de 100 puntos. usar cuando copilot deba evaluar commercial accounts, recomendar tier 1, tier 2 o tier 3, seleccionar cuentas del territorio, detectar datos faltantes, ponderar empresas cotizantes y relaciones internacionales de hiberus, o proponer la siguiente acción de investigación sin modificar sharepoint.
---

# Account Prioritization Hiberus Argentina

Aplicar esta secuencia:

1. Consultar `Commercial Accounts` y relacionar por `Account ID`.
2. Separar hechos confirmados, señales, hipótesis y datos desconocidos.
3. Puntuar cada criterio con `references/scoring-rubric.md`.
4. Calcular score total, cobertura de datos y confianza.
5. Recomendar Tier aplicando los guardrails.
6. Identificar el dato faltante que más podría cambiar la decisión.
7. Proponer una próxima acción concreta.
8. No actualizar SharePoint. Mostrar valor actual y valor recomendado.

## Scoring

- Potencial económico en Argentina: 15.
- Afinidad con capacidades de Hiberus: 15.
- Relación internacional con Hiberus: 15.
- Acceso y relaciones existentes: 15.
- Señales de inversión o transformación: 10.
- Empresa cotizante o inteligencia disponible: 10.
- Posibilidad de cierre en 120 días: 10.
- Credenciales y diferenciación: 5.
- Barreras de entrada y riesgo competitivo: 5.

## Confianza

- Alta: cobertura igual o mayor a 80% y sin datos críticos desconocidos.
- Media: cobertura entre 60% y 79% o un dato crítico desconocido.
- Baja: cobertura menor a 60% o dos o más datos críticos desconocidos.

Datos críticos: relación internacional, acceso, señales y cierre en 120 días.

No normalizar el score por información faltante. Un dato desconocido recibe 0 provisional y debe quedar señalado.

## Tier

- Tier 1: 75 a 100, confianza media o alta y ruta de acción verificable.
- Tier 1 provisional: score de Tier 1 con confianza baja o datos críticos incompletos.
- Tier 2: 50 a 74.
- Tier 3: menos de 50.

No asignar Tier 1 solo por facturación o cotización bursátil.

## Salida

Para cada cuenta mostrar:

- Account ID y empresa.
- Score actual y recomendado.
- Tier actual y recomendado.
- Confianza.
- Puntaje por criterio.
- Hechos, señales e hipótesis.
- Motivo de prioridad.
- Datos faltantes.
- Próxima acción, responsable sugerido y resultado esperado.

Cuando se solicite salida estructurada, usar `references/output-schema.json`.
