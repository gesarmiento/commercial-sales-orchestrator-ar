# Rúbrica de scoring

## Potencial económico, máximo 15
0 sin evidencia; 5 empresa relevante con inversión incierta; 10 gran escala o complejidad; 15 capacidad comprobable de contratación enterprise.

## Afinidad Hiberus, máximo 15
0 sin ajuste; 5 ajuste teórico; 10 caso de uso plausible; 15 necesidad verificable con capacidad Hiberus aplicable.

## Relación internacional Hiberus, máximo 15
0 sin evidencia; 5 antecedente por verificar; 10 proyecto verificable sin acceso local; 15 relación activa, referente identificado y uso comercial autorizado.

## Acceso, máximo 15
0 sin ruta; 5 contacto frío o indirecto; 10 contacto activo o presentador; 15 múltiples stakeholders o sponsor potencial.

## Señales, máximo 10
0 sin señales; 3 señal antigua; 6 iniciativa reciente; 10 proyecto, presupuesto, licitación o necesidad activa.

## Cotización e inteligencia, máximo 10
0 información insuficiente; 3 información pública básica; 6 reportes oficiales útiles; 10 inteligencia reciente que permite tesis accionable.

## Cierre en 120 días, máximo 10
0 ciclo desconocido; 3 acceso inicial; 6 necesidad probable y próximo paso; 10 urgencia, sponsor, proceso y primera fase cerrable.

## Diferenciación, máximo 5
0 sin credencial; 2 capacidad genérica; 4 caso o especialista relevante; 5 referencia autorizada y equipo disponible.

## Barreras, máximo 5
0 barreras severas; 2 competencia fuerte; 4 barreras manejables; 5 ventana favorable o acceso diferencial.
