# Hitos de 120 días

## Días 1-15
Reunión exploratoria, problema preliminar, responsable, segundo stakeholder y próximo paso fechado.

## Días 16-35
Dolor e impacto, sponsor, alcance preliminar, criterios, proceso inicial y competencia.

## Días 36-60
Solución y alcance validados, especialistas, estimación, riesgos y proceso de aprobación.

## Días 61-90
Propuesta al grupo decisor, objeciones, negociación, fecha de decisión y paper process.

## Días 91-120
Negociación final, contratación y decisión ganada, perdida, postergada o primera fase contratada.
