# MEDDPICC práctico

Evaluar cada dimensión como Confirmada, Parcial, Desconocida o En riesgo.

- Metrics: impacto medible o criterio de éxito aceptado.
- Economic Buyer: persona que autoriza y acceso directo o patrocinado.
- Decision Criteria: criterios técnicos, económicos, de riesgo y delivery.
- Decision Process: participantes, secuencia, hitos y fecha de decisión.
- Paper Process: Compras, legales, alta de proveedor, contrato, moneda e impuestos.
- Identify Pain: problema, impacto y prioridad validados por el cliente.
- Champion: persona con influencia que impulsa y facilita acceso.
- Competition: incumbente, desarrollo interno, no hacer nada y competidores externos.

Cobertura: Confirmada=1; Parcial=0,5; Desconocida o En riesgo=0.
