# Apoyo ejecutivo

## Diego Zorzoli
Usar para estrategia comercial, recursos, especialistas, condiciones, negociación, ownership, go/no-go y acceso comercial.

## Juan Angel Orejudo
Usar para acceso C-suite, representación institucional, activación internacional, reunión estratégica, oportunidad de alto valor o expansión regional.

Antes de recomendar apoyo indicar cuenta, oportunidad, etapa, interlocutor, objetivo, acción solicitada, preparación, fecha, resultado esperado y por qué Gustavo no puede obtener el mismo resultado solo.
