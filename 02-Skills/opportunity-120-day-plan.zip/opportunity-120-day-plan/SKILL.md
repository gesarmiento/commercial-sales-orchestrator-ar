---
name: opportunity-120-day-plan
description: diseña, evalúa y actualiza planes comerciales de 90 a 120 días para oportunidades enterprise de hiberus argentina. usar cuando copilot deba revisar commercial opportunities, determinar etapa real, aplicar meddpicc, detectar bloqueos o estancamientos, calcular fase y velocidad, crear acciones de los próximos 15 días, proponer una primera contratación acotada o evaluar apoyo de diego zorzoli o juan angel orejudo sin modificar sharepoint.
---

# Opportunity 120-Day Plan Hiberus Argentina

Aplicar esta secuencia:

1. Consultar `Commercial Opportunities` e identificar `Opportunity ID` y `Account ID`.
2. Consultar `Commercial Accounts`, `Commercial Contacts` y `Sales Actions` relacionadas.
3. Separar hechos, señales, hipótesis y datos desconocidos.
4. Determinar etapa real, edad, días en etapa y días sin avance.
5. Evaluar MEDDPICC con `references/meddpicc-rubric.md`.
6. Determinar fase del ciclo y comparar hitos con `references/phase-milestones.md`.
7. Detectar alertas de velocidad y bloqueos.
8. Evaluar si el alcance completo puede decidirse o contratarse en 120 días.
9. Si no, proponer una primera contratación útil y cerrable.
10. Definir máximo siete acciones de los próximos 15 días con responsable, fecha y resultado esperado.
11. Evaluar apoyo ejecutivo con `references/executive-support.md`.
12. No actualizar SharePoint. Mostrar cambios propuestos y requerir aprobación externa.

## Etapas

0 Cuenta objetivo; 1 Hipótesis formulada; 2 Contacto iniciado; 3 Reunión exploratoria; 4 Necesidad validada; 5 Oportunidad calificada; 6 Solución y alcance; 7 Propuesta presentada; 8 Negociación y contratación; 9 Ganada; 10 Perdida o postergada.

No avanzar de etapa solo por enviar un correo, realizar una reunión o presentar una propuesta.

## Alertas

- 7 días sin próximo paso confirmado.
- 14 días sin avance verificable.
- 21 días en la misma etapa.
- Propuesta sin fecha de decisión.
- Sin sponsor al día 35.
- Proceso de compra desconocido al día 60.
- Compras no involucrada al día 75 cuando corresponda.

## Semáforo

- Verde: hitos cumplidos, sponsor activo, próximo paso fechado y sin bloqueo crítico.
- Amarillo: uno o dos vacíos materiales con ruta de recuperación en 15 días.
- Rojo: sin dolor validado, sponsor o proceso; 14 días sin avance; o fecha objetivo no creíble.

## Primera contratación acotada

Evaluar assessment, discovery, workshop, proof of concept, diagnóstico, roadmap, FinOps assessment, evaluación de seguridad, piloto, staffing inicial, bolsa de horas o fase inicial. No fragmentar artificialmente el alcance.

## Salida

- Resumen ejecutivo.
- Etapa real, día del ciclo, fase, semáforo y fecha objetivo.
- Hechos, señales, hipótesis y desconocidos.
- MEDDPICC por dimensión: estado, evidencia, brecha y acción.
- Alertas y bloqueos.
- Plan inverso de 120 días.
- Acciones de los próximos 15 días.
- Primera contratación recomendada, si corresponde.
- Apoyo ejecutivo recomendado.
- Riesgos, criterios de no-go y próxima revisión.

Cuando se solicite JSON, usar `references/output-schema.json`.
